package com.cdac.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cdac.Repository.BooksRepository;
import com.cdac.Service.BooksService;
import com.cdac.dto.Books;
import com.cdac.dto.Message;


@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class BooksController {

	@Autowired
	private BooksService booksService;
	
	@PostMapping(value = "AddBooks")
	public Message index(@RequestBody Books books) {
		System.out.println(books);
		if(booksService.AddBook(books)){
			return new Message("Book Added", true);
			}
			return new Message("Book Already Added", false);
		}
	
	@DeleteMapping(value = "deleteBooks/{id}")
	public Message deleteBook(@PathVariable int id) {
		System.out.println(id);
		booksService.deleteBook(id);
		return new Message("Books Removed",true);
	}
	
	@GetMapping(value = "Books")
	public List<Books> getBooks(){
		//System.out.println(id);
		return booksService.getAllBooks();
	}
	
	
	
	@PutMapping("/Updatebooks")  
	private void update(@RequestBody Books books)   
	{  
	booksService.update(books);
	 
	}  
	
//	@GetMapping("/getbook")  
//	private void update(@PathVariable int id)   
//	{  
//	booksService.getBooksById(id);
//	 
//	}  
	
	
//	@PutMapping("/books/{id}")
//	public ResponseEntity<Books> updateBooks(@PathVariable Integer id, @RequestBody Books booksDetails){
//		
//		//Books books = booksRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" +id));
//		
////		books.setBookname(booksDetails.getBookname());
////		books.setBookPrice(booksDetails.getBookPrice());
////		books.setBookRent(booksDetails.getBookRent());
////		books.setAuthorName(booksDetails.getAuthorName());
////		books.setDescription(booksDetails.getDescription());
////		books.setEdition(booksDetails.getEdition());
//		
//		//Books updateBooks = booksRepository.save();
//		return null;
//	}
//	
//	@GetMapping("/Books/{id}")
//	public Books getBooksById(@PathVariable Integer id) {
//		List<Books> Books = booksService.findById(id);
//		return Books;
//		return booksService.findById(id);
//	}
	
//	@GetMapping("/Books/{id}")
//	public Books getBooksById(@PathVariable Integer id) {
//		Books Books = BooksRepository.find
//				findById(id).orElseThrow(() -> new ResourceNotF)
				//BooksRepository.findById(id).orElseThrow(exceptionSupplier)
//	}
	
	
//	@PutMapping("/Books/update/{id}")
//	public ResponseEntity<Books> updateBooks(Long id, @RequestBody Books books){
//		
//		
//		
//	}
	
//	@PutMapping("/Updatebooks/{id}")  
//	private void update(@RequestBody Books books,@PathVariable Integer id)   
//	{  
//	booksService.update(books, id);
//	 
//	}  

}
