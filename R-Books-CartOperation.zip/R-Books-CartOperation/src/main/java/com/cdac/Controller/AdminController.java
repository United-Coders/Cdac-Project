package com.cdac.Controller;



import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cdac.Repository.AdminRepository;
import com.cdac.Service.AdminService;
import com.cdac.dto.Message;
import com.cdac.dto.Admin;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class AdminController {
    
	@Autowired
	private AdminService adminService;
	
	@PostMapping(value = "registerAdmin")
	public Message index(@RequestBody Admin admin) {
			System.out.println(admin);
			if(adminService.AddAdmin(admin)) {
				return new Message("Admin Registered", true);
			}
			
			return new Message("Admin Already Registered", false);
	}
	
	@PostMapping(value = "AdminValidate")
	public Message adminValidate(@RequestBody Admin admin) {
			System.out.println(admin);
			if(adminService.AdminValidate(admin)) {
				return new Message("Admin Validated", true);
			}
			return new Message("Invalid Credentials", false);
	}
	
	
	@DeleteMapping(value = "deleteAdmin/{id}")
	public Message deleteAdmin(@PathVariable int id) {
			System.out.println(id);
			adminService.deleteAdmin(id);
			return new Message("Record Removed",true);
	}
	
	@GetMapping(value = "display1" )
	public List<Admin> getAdmins() {
			//System.out.println(id);
			
			return adminService.getAllAdmins();
	}
	
//	@RequestMapping(value = "/getDateAndTime")
//	public String getDateAndTime() {
//	
//	    var now = LocalDateTime.now();
//	    var dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
//	    var date_time = dtf.format(now);
//	
//	    var params = new HashMap<String, Object>();
//	    params.put("date_time", date_time);
//	    return params.toString();
//	  //  return new ModelAndView("showMessage", params).toString();
//	}
	
}
