package com.cdac.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cdac.Service.LibrarianService;
import com.cdac.dto.Librarian;
import com.cdac.dto.Message;
import com.cdac.dto.User;


@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class LibrarianController {

	
	@Autowired
	private LibrarianService librarianService;
	
	
	@PostMapping(value = "registerLibrarian")
	public Message index(@RequestBody Librarian librarian) {
			System.out.println(librarian);
			if(librarianService.AddLibrarian(librarian)) {
				return new Message("Librarian Registered", true);
			}
			
			return new Message("Librarian Already Registered", false);
	}
	
	@PostMapping(value = "LibrarianValidate")
	public Message LibrarianValidate(@RequestBody Librarian librarian) {
			System.out.println(librarian);
			if(librarianService.LibrarianValidate(librarian)) {
				return new Message("Librarian Validated", true);
			}
			return new Message("Invalid Credentials", false);
	}
	
	
	@DeleteMapping(value = "deleteLibrarian/{id}")
	public Message deleteLibrarian(@PathVariable int id) {
			System.out.println(id);
			librarianService.deleteLibrarian(id);
			return new Message("Record Removed",true);
	}
	
	@GetMapping(value = "Librarydisplay" )
	public List<Librarian> getLibrarian() {
			//System.out.println(id);
			
			return librarianService.getAllLibrarian();
	}
	
}
