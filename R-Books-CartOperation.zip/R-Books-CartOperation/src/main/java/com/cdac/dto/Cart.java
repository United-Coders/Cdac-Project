package com.cdac.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "cart")
public class Cart {
	
	
	    @Id
	   @GeneratedValue
    private int cartId;
    private String cbookName;
    private String cauthorName;
    private int cbookPrice;
    private int userId;
    
	public Cart() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getCartId() {
		return cartId;
	}

	public void setCartId(int cartId) {
		this.cartId = cartId;
	}

	public String getCbookName() {
		return cbookName;
	}

	public void setCbookName(String cbookName) {
		this.cbookName = cbookName;
	}

	public String getCauthorName() {
		return cauthorName;
	}

	public void setCauthorName(String cauthorName) {
		this.cauthorName = cauthorName;
	}

	public int getCbookPrice() {
		return cbookPrice;
	}

	public void setCbookPrice(int cbookPrice) {
		this.cbookPrice = cbookPrice;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}
    
    
    
    
	
}
