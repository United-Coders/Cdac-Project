package com.cdac.Service;

import com.cdac.dto.Admin;

import java.util.List;

public interface AdminService {
    boolean AddAdmin(Admin amin);
	
	List<Admin> getAllAdmins();
	
	boolean AdminValidate(Admin admin);
	
	boolean deleteAdmin(int id);
    
}
