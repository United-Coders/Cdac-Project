package com.cdac.Service;

import java.util.List;

import com.cdac.dto.Librarian;

public interface LibrarianService {
	
	
    boolean AddLibrarian(Librarian librarian);
	
	List<Librarian> getAllLibrarian();
	
	boolean LibrarianValidate(Librarian librarian);
	
	boolean deleteLibrarian(int id);
}
