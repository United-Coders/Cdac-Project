package com.cdac.Repository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cdac.dto.Admin;











@Repository
public interface AdminRepository extends CrudRepository<Admin, Integer>{
	public Admin findByEmailAndPassword(String email, String password);
}
