import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FooterComponent } from './footer/footer.component';
import { ForgetComponent } from './forget/forget.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { UserhomeComponent } from './userhome/userhome.component';
import { UserregisterComponent } from './userregister/userregister.component';

const routes: Routes = [
  
  { path: "login",component: LoginComponent },
  { path: "header",component: HeaderComponent },
  { path: "footer",component: FooterComponent },
  { path: "userregister",component: UserregisterComponent },
  { path: "forget",component: ForgetComponent },
  { path: "home",component: HomeComponent },
  { path: "userhome",component: UserhomeComponent },
  
  
 
  
 
  { path: "", redirectTo:'/home', pathMatch:'full'},
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
