
import { Component, OnInit } from '@angular/core';
import { HttpSpringService, User, Message } from './../http-spring.service';

import { Observable } from 'rxjs';



@Component({
  selector: 'app-userregister',
  templateUrl: './userregister.component.html',
  styleUrls: ['./userregister.component.css'],
})
export class UserregisterComponent implements OnInit {
  user: User = new User( null ,null, null, null, null, null);

  public message: Message;
  public mssg: string = "";
  
  constructor(private httpSpringService: HttpSpringService) { }

  ngOnInit(): void {
  }

  public RegisterUser1(obj: any) {
    this.httpSpringService.RegisterUser(obj).subscribe(res => {
      this.user.firstname = "";
      this.user.lastname = "";
      this.user.email = "";
      this.user.password = "";
      this.user.contact = "";
      this.message = <Message>res;
      console.log(this.message.message);
      if (this.message.flag) {
        this.httpSpringService.LoginUserPage();
      }
      else {
        this.mssg = this.message.message;
      }

    });
  }

  public LoginUser() {
    this.httpSpringService.LoginUserPage();
  }


  

}

