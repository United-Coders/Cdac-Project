import { Component, OnInit } from '@angular/core';
import { faStar,faStarHalfAlt } from '@fortawesome/free-solid-svg-icons'


@Component({
  selector: 'app-userhome',
  templateUrl: './userhome.component.html',
  styleUrls: ['./userhome.component.css']
})
export class UserhomeComponent implements OnInit {
  public faStar = faStar;
  public faStarHalfAlt = faStarHalfAlt;
  constructor() { }

  ngOnInit(): void {
  }

}
