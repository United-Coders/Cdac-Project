import { Component, OnInit } from '@angular/core';
import { HttpSpringService, User, Message } from './../http-spring.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  public mssg: string = "";
  message: Message = new Message(null, null);
  user: User = new User(null, null, null, null, null, null);

  constructor( private httpSpringService: HttpSpringService) { }

  ngOnInit(): void {
  }

  public LoginValidate(user: User) {
    return this.httpSpringService.LoginValidate(user).subscribe(res => {
      this.message = <Message>res;
      if (this.message.flag) {
        console.log(this.message.message);
        this.httpSpringService.UserHomePage();
      } else {
        this.mssg = this.message.message;
      }
    });
  }

}
