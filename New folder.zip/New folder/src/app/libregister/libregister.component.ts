import { Component, OnInit } from '@angular/core';
import { from } from 'rxjs';
import { LibrarianserviceService , Librarian , Message} from './../librarianservice.service';

@Component({
  selector: 'app-libregister',
  templateUrl: './libregister.component.html',
  styleUrls: ['./libregister.component.css']
})
export class LibregisterComponent implements OnInit {

  librarian: Librarian = new Librarian( null,null ,null, null, null, null, null);

  public message: Message;
  public mssg: string = "";
  

  constructor(private librarianserviceService : LibrarianserviceService ) { }

  ngOnInit(): void {
  }

  public RegisterLibrarian1(obj: any) {
    this.librarianserviceService.RegisterLibrarian(obj).subscribe(res => {
      this.librarian.name = "";
      this.librarian.email = "";
      this.librarian.password = "";
      this.librarian.phone = "";
      this.librarian.licence_no = "";
      this.librarian.address = "";
      this.message = <Message>res;
      console.log(this.message.message);
      if (this.message.flag) {
        this.librarianserviceService.LoginLibrarianPage();
      }
      else {
        this.mssg = this.message.message;
      }

    });
  }


  public LoginLibrarian() {
    this.librarianserviceService.LoginLibrarianPage();
  }

}
