import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';


export class Message {
  constructor(
    public message: string,
    public flag: boolean
  ) { }
}

export class Librarian {
  constructor(
    public lib_id: number,
    public name: string,
    public phone: string,
    public email: string,
    public password: string,
    public licence_no: string,
    public address: string) { }
}




@Injectable({
  providedIn: 'root'
})
export class LibrarianserviceService {

  constructor( private httpClient: HttpClient,
    private router: Router) { }


    public RegisterLibrarian(obj: any) {
      return this.httpClient.post<any>("http://localhost:8080/registerLibrarian", <Librarian>obj);
    }
  
    public LoginValidate1(obj: any) {
      return this.httpClient.post<any>("http://localhost:8080/LibrarianValidate", <Librarian>obj);
    }

    public RegisterLibrarianPage() {
      return this.router.navigate(['libregister']);
    }
    public LibrarianHomePage() {
      return this.router.navigate(['librarianhome']);
    }

    public LoginLibrarianPage() {
      return this.router.navigate(['liblogin']);
    }

}
