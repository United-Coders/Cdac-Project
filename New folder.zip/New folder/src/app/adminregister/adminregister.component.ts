import { Component, OnInit } from '@angular/core';
import { from } from 'rxjs';
import { AdminserviceService , Admin , Message} from './../adminservice.service';

@Component({
  selector: 'app-adminregister',
  templateUrl: './adminregister.component.html',
  styleUrls: ['./adminregister.component.css']
})
export class AdminregisterComponent implements OnInit {

  admin: Admin = new Admin( null ,null, null, null, null, null);

  public message: Message;
  public mssg: string = "";

  constructor(private adminserviceService : AdminserviceService) { }

  ngOnInit(): void {
  }

  public RegisterAdmin(obj: any) {
    this.adminserviceService.RegisterAdmin(obj).subscribe(res => {
      this.admin.firstName = "";
      this.admin.lastName = "";
      this.admin.email = "";
      this.admin.password = "";
      this.admin.phone = "";
      this.message = <Message>res;
      console.log(this.message.message);
      if (this.message.flag) {
        this.adminserviceService.LoginAdminPage();
      }
      else {
        this.mssg = this.message.message;
      }

    });
  }


  public LoginAdmin() {
    this.adminserviceService.LoginAdminPage();
  }

}
