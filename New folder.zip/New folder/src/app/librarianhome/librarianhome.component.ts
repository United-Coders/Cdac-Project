import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-librarianhome',
  templateUrl: './librarianhome.component.html',
  styleUrls: ['./librarianhome.component.css']
})
export class LibrarianhomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
