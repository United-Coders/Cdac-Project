package com.cdac.Service;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.Repository.AdminRepository;
import com.cdac.dto.Admin;



@Service
public class AdminServiceImple implements AdminService{
	
	@Autowired
	private AdminRepository adminRepository;

	@Override
	public boolean AddAdmin(Admin admin) {
		if(null == adminRepository.save(admin)) {
			return false;
		}
		return true;
	}

	@Override
	public List<Admin> getAllAdmins() {
		Iterable<Admin> UI = adminRepository.findAll();
		Iterator<Admin> UItr = UI.iterator();
		List<Admin> ULi = new ArrayList<Admin>();
		while(UItr.hasNext()) {
			ULi.add(UItr.next());
		}
		return ULi;
	}

	@Override
	public boolean AdminValidate(Admin admin) {
		if(adminRepository.findByEmailAndPassword(admin.getEmail(), admin.getPassword()) != null) {
			return true;
		}
		return false;
	}

	@Override
	public boolean deleteAdmin(int id) {
		adminRepository.deleteById(id);
		return true;
	}
	

	

}
