package com.cdac.Service;

import com.cdac.dto.User;

import java.util.List;

public interface UserService {
    boolean AddUser(User user);
	
	List<User> getAllUsers();
	
	boolean UserValidate(User user);
	
	boolean deleteUser(int id);
    
}
