package com.cdac.Service;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.Repository.UserRepository;
import com.cdac.dto.User;



@Service
public class UserServiceImple implements UserService{
	
	@Autowired
	private UserRepository userRepository;

	@Override
	public boolean AddUser(User user) {
		if(null == userRepository.save(user)) {
			return false;
		}
		return true;
	}

	@Override
	public List<User> getAllUsers() {
		Iterable<User> UI = userRepository.findAll();
		Iterator<User> UItr = UI.iterator();
		List<User> ULi = new ArrayList<User>();
		while(UItr.hasNext()) {
			ULi.add(UItr.next());
		}
		return ULi;
	}

	@Override
	public boolean UserValidate(User user) {
		if(userRepository.findByEmailAndPassword(user.getEmail(), user.getPassword()) != null) {
			return true;
		}
		return false;
	}

	@Override
	public boolean deleteUser(int id) {
		userRepository.deleteById(id);
		return true;
	}
	

	

}
