package com.cdac.Repository;

import org.springframework.data.repository.CrudRepository;

import com.cdac.dto.Librarian;


public interface LibrarianRepository extends CrudRepository<Librarian, Integer>{
	public Librarian findByEmailAndPassword(String email, String password);
}
